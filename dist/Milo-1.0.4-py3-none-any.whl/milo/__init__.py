"""Declare Milo as a package."""
