#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run Milo."""

from milo import main

main.main()
