#!/usr/bin/env python

from os.path import dirname

prefix = dirname(__file__)
